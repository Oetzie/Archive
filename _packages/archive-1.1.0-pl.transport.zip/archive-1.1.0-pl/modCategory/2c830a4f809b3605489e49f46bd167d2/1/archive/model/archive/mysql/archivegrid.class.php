<?php

/**
 * Archive
 *
 * Copyright 2020 by Oene Tjeerd de Bruin <modx@oetzie.nl>
 */

require_once dirname(__DIR__) . '/archivegrid.class.php';

class ArchiveGrid_mysql extends ArchiveGrid
{
}
