<?php

/**
 * Archive
 *
 * Copyright 2020 by Oene Tjeerd de Bruin <modx@oetzie.nl>
 */

$_lang['archive.grid_blog']                                     = 'Blog';
$_lang['archive.grid_blog_desc']                                = 'Manage here all the blog messages.';
$_lang['archive.grid_blog_create']                              = 'Create blog message';
$_lang['archive.grid_blog_update']                              = 'Update blog message';
$_lang['archive.grid_blog_duplicate']                           = 'Duplicate blog message';
$_lang['archive.grid_blog_move']                                = 'Move blog message';
$_lang['archive.grid_blog_unpublish']                           = 'Depublish blog message';
$_lang['archive.grid_blog_publish']                             = 'Publish blog message';
$_lang['archive.grid_blog_remove']                              = 'Delete blog message';
$_lang['archive.grid_blog_recover']                             = 'Recover blog message';
$_lang['archive.grid_blog_show']                                = 'View blog message';
