----------------------
Archive
----------------------
Version: 1.0.2
Author: Oene Tjeerd de Bruin
Contact: info@oetzie.nl
----------------------

This use this component the user needs to have the "archive" permissions.